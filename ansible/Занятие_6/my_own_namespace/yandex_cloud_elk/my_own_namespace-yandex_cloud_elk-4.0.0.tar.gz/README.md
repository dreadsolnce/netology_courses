# Ansible Collection - my_own_namespace.yandex_cloud_elk

## Тестовая коллекция. Эта коллекция создает файл на файловой системе.

## Установка
Как установить коллекцию с помощью `ansible-galaxy`.

```bash
ansible-galaxy collection install my_own_namespace.yandex_cloud_elk

